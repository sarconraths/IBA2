package Papier;

public interface Foldable {
		
	public void falten(); 
	
	public void falten(int wieOft);
	
	public void entfalten(); 
	
	public void entfalten(int wieOft);

}
