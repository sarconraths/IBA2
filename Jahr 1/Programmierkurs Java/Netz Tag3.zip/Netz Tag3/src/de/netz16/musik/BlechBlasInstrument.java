package de.netz16.musik;

public abstract class BlechBlasInstrument extends BlasInstrument {


}
