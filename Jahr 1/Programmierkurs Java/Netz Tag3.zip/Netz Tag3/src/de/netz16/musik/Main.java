package de.netz16.musik;

public class Main {

	public static void main(String[] args) {
		MusikInstrument mi = new StreichInstrument(); 
		mi.ton();
	
		Trompete tr = new Trompete(); 
		tr.ton();
	}

}
