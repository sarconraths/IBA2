package de.netz16.musik;

public abstract class MusikInstrument {
	
	public abstract void ton(); 

}
