package de.netz16.musik;

public class Trompete extends BlechBlasInstrument {

	public void ton() {
		System.out.println("T�r���");
		
	}

	
}
