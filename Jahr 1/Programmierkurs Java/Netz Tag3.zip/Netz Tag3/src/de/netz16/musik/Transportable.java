package de.netz16.musik;

public interface Transportable {
	public void verpacken();
	public int getGewicht();	
}


