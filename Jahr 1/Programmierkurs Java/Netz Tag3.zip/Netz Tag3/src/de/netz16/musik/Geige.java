package de.netz16.musik;

public class Geige extends StreichInstrument {

}
