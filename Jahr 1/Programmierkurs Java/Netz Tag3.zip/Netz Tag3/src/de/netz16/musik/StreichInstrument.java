package de.netz16.musik;

public class StreichInstrument extends MusikInstrument {

	@Override
	public void ton() {
		System.out.println("Quietsch");
		
	}
	
	public void stimmen() {
		// TODO Auto-generated method stub
		
	}

}
